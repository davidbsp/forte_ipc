#!/bin/bash
source ~/rosbuild_ws/setup.bash
export ROS_PACKAGE_PATH=~/rosbuild_ws:~/catkin_ws:$ROS_PACKAGE_PATH
xterm -hold -e "roslaunch /home/forte/rosbuild_ws/cpr_rviz_plugin/cpr_mover6.launch" &

source ~/catkin_ws/devel/setup.bash
export ROS_PACKAGE_PATH=~/catkin_ws:$ROS_PACKAGE_PATH
cd ~/catkin_ws/src/cpr_mover
sleep 5
rosrun cpr_mover cpr_mover
exit 0
