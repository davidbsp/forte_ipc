cpr_rviz_plugin
===============

ROS RViz plugin to command the CPR Mover4 and Mover6 robots.

DOCUMENTATION --> /doc folder in the cpr_mover package found on www.github.com/CPR-Robots

Allows to push commands like connect or enable, and to jog the joints
Displays the joint values


